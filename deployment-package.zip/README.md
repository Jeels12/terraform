# Deployment Package - Flask + Express on AWS with Terraform

This package contains:
- `backend-flask/` : simple Flask app with Dockerfile
- `frontend-express/` : simple Express app with Dockerfile
- `docker-compose.yml` : for local testing or single-EC2 deployment
- `nginx/conf.d/app.conf` : nginx reverse-proxy config (for docker-compose)
- `terraform/` : Terraform templates and example user-data scripts for:
    - Part1: Single EC2 running both services (via docker-compose)
    - Part2: Two EC2 instances, one for backend and one for frontend
    - Part3: ECR + ECS + ALB templates (simplified)
- `report.docx` : Word document containing commands, sample outputs and placeholders for screenshots

## How to use

1. Update occurrences of `YOUR_USERNAME/YOUR_REPO` in the terraform user-data scripts with your GitHub repo URL.
2. Push this repo to GitHub:
   ```
   git init
   git add .
   git commit -m "initial commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo>.git
   git push -u origin main
   ```
3. Follow the Terraform steps in `terraform/part1_single_ec2/main.tf` (and others).
4. Replace placeholders in Terraform variables (key_name, etc.) before `terraform apply`.

## Local testing with Docker Compose
```
docker compose up -d --build
```
Visit `http://localhost/` to see the frontend, and `http://localhost/api/health` for backend health.

## Notes
- The Terraform templates provided are opinionated and simplified for educational/demo use.
- For production use, harden security groups, use proper IAM roles, SSL/TLS, and automated CI/CD pipelines.
