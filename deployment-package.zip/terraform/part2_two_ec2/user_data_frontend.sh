#!/bin/bash
apt-get update -y
apt-get install -y nodejs npm git
cd /home/ubuntu
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git app || (cd app && git pull)
cd app/frontend-express
npm install
nohup node server.js > /tmp/express.log 2>&1 &
