#!/bin/bash
apt-get update -y
apt-get install -y python3 python3-venv python3-pip git
cd /home/ubuntu
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git app || (cd app && git pull)
cd app/backend-flask
python3 -m venv venv
. venv/bin/activate
pip install -r requirements.txt
nohup gunicorn --bind 0.0.0.0:5000 app:app --workers 2 > /tmp/gunicorn.log 2>&1 &
