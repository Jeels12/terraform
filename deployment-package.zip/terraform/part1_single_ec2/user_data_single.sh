#!/bin/bash
apt-get update -y
apt-get install -y docker.io docker-compose git
systemctl start docker
systemctl enable docker
cd /home/ubuntu
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git app || (cd app && git pull)
cd app
docker compose up -d --build
