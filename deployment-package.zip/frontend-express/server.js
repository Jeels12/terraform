const express = require('express');
const axios = require('axios');
const app = express();
const PORT = process.env.PORT || 3000;
const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:5000';

app.get('/', (req, res) => {
  res.send(`<h1>Express Frontend</h1><p>Call backend: <a href="/call">/call</a></p>`);
});

app.get('/call', async (req, res) => {
  try {
    const r = await axios.get(`${BACKEND_URL}/api/data`);
    res.json({ from_backend: r.data });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

app.listen(PORT, () => {
  console.log('Express frontend listening on', PORT);
});
